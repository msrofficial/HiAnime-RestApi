const someAnimes = {
  keywords: ['one', 'death', 'baccano', 'steins+gate', 'code+geass', 'clanned'],
  ids: [
    'steins-gate-3',
    'baccano-129',
    'code-geass-lelouch-of-the-rebellion-41',
    'attack-on-titan-112',
  ],
  characterIds: [
    'character:mayuri-shiina-151',
    'character:kurisu-makise-14',
    'character:suzuha-amane-605',
    'character:rintarou-okabe-8',
  ],
  voiceActorIds: ['people:yukari-tamura-77', 'people:kana-hanazawa-1', 'people:mamoru-miyano-3'],
  episodesIds: [
    'steinsgate-3::ep=213',
    'baccano-129::ep=3809',
    'code-geass-lelouch-of-the-rebellion-41::ep=1158',
  ],

  servers: ['hd-1', 'hd-2', 'hd-3', 'megaplay', 'vidwish'],
  producers: ['toei-animation', 'fuji-tv', 'mappa', 'wit-studio'],
};

export default someAnimes;
