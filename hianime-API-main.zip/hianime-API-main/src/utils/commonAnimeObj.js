export const commonAnimeObj = () => ({
  title: null,
  alternativeTitle: null,
  id: null,
  poster: null,
});

export const episodeObj = () => ({
  episodes: {
    sub: null,
    dub: null,
    eps: null,
  },
});
