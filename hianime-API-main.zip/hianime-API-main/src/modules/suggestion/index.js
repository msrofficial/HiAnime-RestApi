import suggestionSchema from './suggestion.schema';
import suggestionHandler from './suggestion.handler';

export { suggestionSchema as schema, suggestionHandler as handler };
