import monthlyScheduleHandler from './monthlySchedule.handler';
import monthlyScheduleSchema from './monthlySchedule.schema';

export { monthlyScheduleSchema as schema, monthlyScheduleHandler as handler };
