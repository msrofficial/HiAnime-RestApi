import nextEpScheduleHandler from './nextEpSchedule.handler';
import nextEpScheduleSchema from './nextEpSchedule.schema';

export { nextEpScheduleHandler as handler, nextEpScheduleSchema as schema };
