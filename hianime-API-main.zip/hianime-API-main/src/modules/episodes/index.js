import episodesHandler from './episodes.handler';
import episodesSchema from './episodes.schema';

export { episodesHandler as handler, episodesSchema as schema };
