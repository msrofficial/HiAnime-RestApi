import animeInfoHandler from './animeInfo.handler';
import animeInfoSchema from './animeInfo.schema';

export { animeInfoSchema as schema, animeInfoHandler as handler };
