import randomAnimeInfoSchema from './randomAnimeInfo.schema';
import randomAnimeInfoHandler from './randomAnimeInfo.handler';

export { randomAnimeInfoHandler as handler, randomAnimeInfoSchema as schema };
