import genreHandler from './genre.handler';
import genreSchema from './genre.schema';

export { genreHandler as handler, genreSchema as schema };
