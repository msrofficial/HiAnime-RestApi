import azListHandler from './azList.handler';
import azListSchema from './azList.schema';

export { azListHandler as handler, azListSchema as schema };
