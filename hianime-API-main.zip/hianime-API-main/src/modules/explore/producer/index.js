import producerHandler from './producer.handler';
import producerSchema from './producer.schema';

export { producerHandler as handler, producerSchema as schema };
