import searchHandler from './search.handler';
import searchSchema from './search.schema';

export { searchHandler as handler, searchSchema as schema };
