import serversSchema from './servers.schema';
import serversHandler from './servers.handler';

export { serversHandler as handler, serversSchema as schema };
