import voiceActorHandler from './voiceActor.handler';
import voiceActorSchema from './voiceActor.schema';

export { voiceActorHandler as handler, voiceActorSchema as schema };
