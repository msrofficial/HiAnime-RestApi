import animeCharacterHandler from './animeCharacter.handler';
import animeCharacterSchema from './animeCharacter.schema';

export { animeCharacterHandler as handler, animeCharacterSchema as schema };
