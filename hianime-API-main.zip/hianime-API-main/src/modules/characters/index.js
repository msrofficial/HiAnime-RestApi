import charactersHandler from './characters.handler';
import charactersSchema from './characters.schema';

export { charactersHandler as handler, charactersSchema as schema };
