import metaHandler from './meta.handler';
import metaSchema from './meta.schema';

export { metaHandler as handler, metaSchema as schema };
