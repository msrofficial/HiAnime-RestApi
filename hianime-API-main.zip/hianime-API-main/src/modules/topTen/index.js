import topTenSchema from './topTen.schema';
import topTenHandler from './topTen.handler';

export { topTenSchema as schema, topTenHandler as handler };
