import homeSchema from './home.schema';
import homehandler from './home.handler';

export { homeSchema as schema, homehandler as handler };
