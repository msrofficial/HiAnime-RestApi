import spotlightSchema from './spotlight.schema';
import spotlightHandler from './spotlight.handler';

export { spotlightHandler as handler, spotlightSchema as schema };
